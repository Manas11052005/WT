const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const PORT = 3003;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

let books = []; // In-memory book collection

// a. Add a new book
app.post("/books", (req, res) => {
  const { title, author, isbn, year } = req.body;

  // Check if book with same ISBN exists
  const exists = books.some((book) => book.isbn === isbn);
  if (exists) {
    return res.status(400).send("Book with this ISBN already exists.");
  }

  books.push({ title, author, isbn, year });
  res.send("Book added successfully.");
});

// b. Retrieve all books
app.get("/books", (req, res) => {
  res.json(books);
});

// c. Delete a book by ISBN
app.delete("/books/:isbn", (req, res) => {
  const isbn = req.params.isbn;
  const index = books.findIndex((book) => book.isbn === isbn);

  if (index !== -1) {
    books.splice(index, 1);
    res.send("Book deleted successfully.");
  } else {
    res.status(404).send("Book not found.");
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
