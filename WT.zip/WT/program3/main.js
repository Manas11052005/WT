// main.js
import { add, subtract } from "./maths.js";

console.log("Addition:", add(10, 5)); // 15
console.log("Subtraction:", subtract(10, 5)); // 5
