const express = require("express");
const mysql = require("mysql");
const bodyParser = require("body-parser");
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

// MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Purva@1209",
  database: "employee_db",
});

db.connect((err) => {
  if (err) throw err;
  console.log("MySQL Connected");
});

// Show all employees
app.get("/", (req, res) => {
  db.query("SELECT * FROM employees", (err, results) => {
    if (err) throw err;
    res.render("index", { employees: results });
  });
});

// Handle search
app.post("/search", (req, res) => {
  const firstName = req.body.firstName;
  db.query(
    "SELECT * FROM employees WHERE first_name = ?",
    [firstName],
    (err, results) => {
      if (err) throw err;
      if (results.length > 0) {
        res.render("result", { employee: results[0] });
      } else {
        res.send("<h2>Data not found</h2>");
      }
    }
  );
});

app.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});
