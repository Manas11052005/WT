const express = require("express");
const bodyParser = require("body-parser");
const db = require("./db");
const path = require("path");

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static("public"));

// Route to fetch all students
app.get("/students", (req, res) => {
  db.query("SELECT * FROM students", (err, results) => {
    if (err) return res.status(500).send("Database error");
    res.json(results);
  });
});

// Route to update student info by rollno
app.post("/update", (req, res) => {
  const { rollno, name, email, branch } = req.body;

  const query = `
    UPDATE students SET 
      name = ?, 
      email = ?, 
      branch = ? 
    WHERE rollno = ?`;

  db.query(query, [name, email, branch, rollno], (err, result) => {
    if (err) return res.status(500).send("Update failed");
    if (result.affectedRows === 0)
      return res.send(
        `<p>No student found with roll number ${rollno}</p><a href="/">Go Back</a>`
      );
    res.send(
      `<p>Student with Roll No ${rollno} updated successfully</p><a href="/">Go Back</a>`
    );
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
