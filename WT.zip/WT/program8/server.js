const express = require("express");
const bodyParser = require("body-parser");
const db = require("./db");
const path = require("path");

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static("public"));

// Get all students
app.get("/students", (req, res) => {
  db.query("SELECT * FROM students", (err, results) => {
    if (err) return res.status(500).send("Database error");
    res.json(results);
  });
});

// Delete a student by roll number
app.post("/delete", (req, res) => {
  const rollno = req.body.rollno;
  db.query("DELETE FROM students WHERE rollno = ?", [rollno], (err, result) => {
    if (err) return res.status(500).send("Delete failed");
    if (result.affectedRows === 0)
      return res.send(
        `<p>No student found with Roll No: ${rollno}</p><a href="/">Go Back</a>`
      );
    res.send(
      `<p>Student with Roll No ${rollno} deleted successfully</p><a href="/">Go Back</a>`
    );
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
