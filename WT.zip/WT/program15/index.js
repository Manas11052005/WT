const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const port = 3008;

app.use(express.json());

const filePath = path.join(__dirname, "data.txt");

// Create file
app.post("/file", (req, res) => {
  const { content } = req.body;
  fs.writeFile(filePath, content, (err) => {
    if (err) return res.status(500).send("Error creating file.");
    res.send("File created.");
  });
});

// Read file
app.get("/file", (req, res) => {
  if (!fs.existsSync(filePath)) {
    return res.status(404).send("File not found.");
  }
  fs.readFile(filePath, "utf-8", (err, data) => {
    if (err) return res.status(500).send("Error reading file.");
    res.send(data);
  });
});

// Update file (append)
app.put("/file", (req, res) => {
  const { content } = req.body;
  if (!fs.existsSync(filePath)) {
    return res.status(404).send("File not found.");
  }
  fs.appendFile(filePath, "\n" + content, (err) => {
    if (err) return res.status(500).send("Error updating file.");
    res.send("File updated.");
  });
});

// Delete file
app.delete("/file", (req, res) => {
  if (!fs.existsSync(filePath)) {
    return res.status(404).send("File not found.");
  }
  fs.unlink(filePath, (err) => {
    if (err) return res.status(500).send("Error deleting file.");
    res.send("File deleted.");
  });
});

app.listen(port, () => {
  console.log(`File system CRUD API running at http://localhost:${port}`);
});
