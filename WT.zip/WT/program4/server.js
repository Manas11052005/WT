// server.js
import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const port = 3000;

// Required to use __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));

// Hardcoded login credentials
const validUser = "admin";
const validPass = "12345";

// Handle POST request from form
app.post("/login", (req, res) => {
  const { userid, password } = req.body;

  if (userid === validUser && password === validPass) {
    res.send("<h2>Login successful!</h2>");
  } else {
    res.send("<h2>Invalid user ID or password.</h2>");
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
