const express = require("express");
const app = express();
const port = 3005;

app.use(express.json()); // to parse JSON request bodies

// In-memory book storage
let books = {};

// Add a new book
app.post("/books", (req, res) => {
  const { title, author, ISBN, year } = req.body;
  if (!title || !author || !ISBN || !year) {
    return res.status(400).json({ message: "Missing book details." });
  }
  if (books[ISBN]) {
    return res
      .status(409)
      .json({ message: "Book with this ISBN already exists." });
  }
  books[ISBN] = { title, author, ISBN, year };
  res
    .status(201)
    .json({ message: "Book added successfully.", book: books[ISBN] });
});

// Retrieve book by ISBN
app.get("/books/:isbn", (req, res) => {
  const isbn = req.params.isbn;
  const book = books[isbn];
  if (!book) {
    return res.status(404).json({ message: "Book not found." });
  }
  res.json(book);
});

// Update existing book
app.put("/books/:isbn", (req, res) => {
  const isbn = req.params.isbn;
  if (!books[isbn]) {
    return res.status(404).json({ message: "Book not found." });
  }
  const { title, author, year } = req.body;
  books[isbn] = {
    ...books[isbn],
    title: title || books[isbn].title,
    author: author || books[isbn].author,
    year: year || books[isbn].year,
  };
  res.json({ message: "Book updated successfully.", book: books[isbn] });
});

app.listen(port, () => {
  console.log(`Book API listening at http://localhost:${port}`);
});
