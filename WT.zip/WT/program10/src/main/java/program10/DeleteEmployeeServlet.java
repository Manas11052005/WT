package program10;

import java.io.*;
import javax.servlet.*;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;

@SuppressWarnings("serial")
//@WebServlet("/DeleteEmployeeServlet")
public class DeleteEmployeeServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String empIdStr = request.getParameter("empId");
        int empId = Integer.parseInt(empIdStr);

        Connection conn = null;
        PreparedStatement checkStmt = null;
        PreparedStatement deleteStmt = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_db", "root", "Purva@1209");

            // Check if employee exists
            String checkQuery = "SELECT * FROM employees WHERE emp_id = ?";
            checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setInt(1, empId);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next()) {
                out.println("<h3>Data not found for Employee ID: " + empId + "</h3>");
            } else {
                // Employee exists, delete record
                String deleteQuery = "DELETE FROM employees WHERE emp_id = ?";
                deleteStmt = conn.prepareStatement(deleteQuery);
                deleteStmt.setInt(1, empId);
                int rows = deleteStmt.executeUpdate();

                out.println("<h3>Employee ID " + empId + " deleted successfully.</h3>");
            }

            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        } finally {
            try { if (checkStmt != null) checkStmt.close(); } catch (Exception e) {}
            try { if (deleteStmt != null) deleteStmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}
