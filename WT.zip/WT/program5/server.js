const express = require("express");
const bodyParser = require("body-parser");
const db = require("./db");
const path = require("path");

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static("public"));

app.post("/submit", (req, res) => {
  const { name, rollno, email, branch } = req.body;
  const query =
    "INSERT INTO students (name, rollno, email, branch) VALUES (?, ?, ?, ?)";

  db.query(query, [name, rollno, email, branch], (err) => {
    if (err) {
      console.error("Error inserting data:", err);
      return res.status(500).send("Database error");
    }
    res.send("Student information submitted successfully!");
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
